#!/bin/sh

set -e

# Make sure only root can run our script
if [[ $EUID -ne 0 ]]; then
   sudo bash $0
   exit 1
fi

if dpkg -l | grep -q patch ; then
        $(exit 0)
	else
	dpkg -i patch*.deb
fi

cp b43-fwcutter /usr/bin/
chmod +x /usr/bin/b43-fwcutter

b43-fwcutter -w /lib/firmware wl_apsta-3.130.20.0.o
tar xfvj broadcom-wl-4.150.10.5.tar.bz2
b43-fwcutter --unsupported -w /lib/firmware broadcom-wl-4.150.10.5/driver/wl_apsta_mimo.o
chmod o+rx /lib/firmware/b43 /lib/firmware/b43legacy

rm -rf broadcom-wl-4.150.10.5

read -p "Press Enter to close.."
